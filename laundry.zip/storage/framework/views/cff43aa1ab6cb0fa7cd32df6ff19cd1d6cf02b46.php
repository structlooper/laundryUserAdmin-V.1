<!-- Main Footer -->
<footer class="main-footer">
    <!-- To the right -->
    <div class="pull-right hidden-xs">
        <?php if(config('admin.show_version')): ?>
        <strong>Version</strong>&nbsp;&nbsp; <?php echo env('APP_VERSION'); ?>

        <?php endif; ?>

    </div>
    <!-- Default to the left -->
    <strong>Powered by <a href="<?php echo env('APP_URL'); ?>" target="_blank"><?php echo env('APP_NAME'); ?></a></strong>
</footer><?php /**PATH /home/u767972256/domains/rithlaundry.com/public_html/vendor/encore/laravel-admin/src/../resources/views/partials/footer.blade.php ENDPATH**/ ?>