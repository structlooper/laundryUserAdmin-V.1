<div class="container">
     <div class="col-md-2 col-md-offset-10">
        <a href='/admin/orders' class='btn btn-info pull-right' style='margin-right:20px;'>Back</a>
    </div>
    <div class="col-lg-6">
        <div class="table-responsive">          
          <table class="table">
            <tbody>
              <tr>
                <th>Order Id</th>
                <td><?php echo e($order_id, false); ?></td>
              </tr>
              <tr>
                <th>Customer Name</th>
                <td><?php echo e($customer_name, false); ?></td>
              </tr>
              <tr>
                <th>Door number/Landmark</th>
                <td><?php echo e($door_no, false); ?></td>
              </tr>
              <tr>
                <th>Address</th>
                <td><?php echo e($address, false); ?></td>
              </tr>
              <tr>
                <th>Expected Delivery Date</th>
                <td><?php echo e($expected_delivery_date, false); ?></td>
              </tr>
            </tbody>
          </table>
        </div>
    </div>
    <div class="col-lg-6">
        <div class="table-responsive">          
          <table class="table">
            <tbody>
              <tr>
                <th>Delivered By</th>
                <td><?php echo e($delivered_by, false); ?></td>
              </tr>
              <tr>
                <th>Payment Mode</th>
                <td><?php echo e($payment_mode, false); ?></td>
              </tr>
              <tr>
                <th>Sub Total</th>
                <td><?php echo e($sub_total, false); ?></td>
              </tr>
              <tr>
                <th>Discount</th>
                <td><?php echo e($discount, false); ?></td>
              </tr>
              <tr>
                <th>Total</th>
                <td><?php echo e($total, false); ?></td>
              </tr>
              <tr>
                <th>Status</th>
                <td><?php echo e($status, false); ?></td>
              </tr>
            </tbody>
          </table>
        </div>
    </div>
    <div class="col-lg-12">
        <h3>Items</h3>
        <table class="table table-hover">
            <thead>
              <tr>
                <th>Service</th>
                <th>Product</th>
                <th>Qty</th>
              </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $order_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($value->service_name, false); ?></td>
                <td><?php echo e($value->product_name, false); ?></td>
                <td><?php echo e($value->qty, false); ?></td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div><?php /**PATH /home/u395397142/domains/menpanitech.com/public_html/rithv2/resources/views/admin/view_orders.blade.php ENDPATH**/ ?>